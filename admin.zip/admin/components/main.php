<?php
$mainHead =' <div class="main-panel">
<div class="content-wrapper">';


$row = '<div class="row">';
$rowEnd =' </div>';


 $mainEnd ='</div></div>';      



    ?>   