<?php
$head='<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Nectar2020 Admin</title>
<!-- plugins:css -->
<link rel="stylesheet" href="node_modules/mdi/css/materialdesignicons.min.css">
<link rel="stylesheet" href="node_modules/simple-line-icons/css/simple-line-icons.css">
<!-- endinject -->
<!-- plugin css for this page -->
<!-- End plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="css/style.css">
<!-- endinject -->
<link rel="shortcut icon" href="../img/lgo3.png" />
</head>';


$footer=' <footer class="footer">
<div class="container-fluid clearfix">
  <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © NECTAR2020  All rights reserved.</span>
  <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center"> <i class="mdi mdi-heart text-danger"></i></span>
</div>
</footer>
<!-- partial -->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>';


$connection=' <script src="node_modules/jquery/dist/jquery.min.js"></script>
<script src="node_modules/popper.js/dist/umd/popper.min.js"></script>
<script src="node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="node_modules/chart.js/dist/Chart.min.js"></script>
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="js/off-canvas.js"></script>
<script src="js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="js/dashboard.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5NXz9eVnyJOA81wimI8WYE08kW_JMe8g&callback=initMap" async defer></script>
<script src="js/maps.js"></script>
<!-- End custom js for this page-->
</body>
';
?>